# static 目录

*静态资源目录*

+ image : 静态图片文件夹
+ js : 静态js文件夹
