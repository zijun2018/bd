# js目录

*静态js目录*

+ we-chat.js : 微信SDK 
