# image目录

*项目的静态图片，注意此文件夹的文件不会被webpack打包*
*所以不会对路径造成应该，试用于需要引用的相对路径*

+ logo.png : pwa需求的logo图片
+ public_delete.png : 文章编辑页面使用的删除按钮
